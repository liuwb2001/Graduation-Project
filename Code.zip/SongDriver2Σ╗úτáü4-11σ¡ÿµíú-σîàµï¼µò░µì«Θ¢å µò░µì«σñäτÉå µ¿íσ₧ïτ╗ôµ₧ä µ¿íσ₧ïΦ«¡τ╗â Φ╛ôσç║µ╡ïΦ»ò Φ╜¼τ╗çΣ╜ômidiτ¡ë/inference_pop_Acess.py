import json
import os
import torch
import numpy as np
import math
from models.muthera_dual import DualMuThera
from models.access import Access
from utils import keys2list
from models.music_feature_extractor_ml import EmoFeatureExtractor

id2notes = json.load(open('dataset/enhance_id2note.json', 'r'))
id2chords = json.load(open('dataset/enhance_id2chord.json', 'r'))

notes2id = json.load(open('dataset/enhance_notes_vocab.json', 'r'))
melody2id = json.load(open('dataset/enhance_melody_vocab.json', 'r'))
chord2id = json.load(open('dataset/enhance_chord_vocab.json', 'r'))


device = 'mps'

def chord_str_to_list(chord_str):
    chord_lst = []
    full_str = chord_str.lstrip('[[').rstrip(']]').split('], [')
    sentence = []
    for ele in full_str:
        ele = '[' + ele + ']'
        sentence.append(ele)
    chord_lst.extend(sentence)
    return chord_lst

def get_data(file_path):
    keys, melody, chord = read_txt(file_path)
    if np.array(melody).shape[0] != 15 * 64:
        print('Melody {}: '.format(np.array(melody).shape[0]), file_path)
    elif np.array(chord).shape[0] != 240:
        print('Chord: {}'.format(np.array(chord).shape[0]), file_path)

    melody = np.array(melody).reshape(15, -1)
    chord = np.array(chord).reshape(15, -1)
    keys = np.array(keys)
    # # 60小节
    # section_num = 60
    # num_row = section_num // 4
    # melody_num = section_num * 16
    # chord_num = section_num * 4
    # tile_num = math.ceil(melody_num / melody.shape[0])
    midi = ''
    for i in range(chord.shape[0]):
        for j in range(chord.shape[1]):
            note_ndx = j * 4
            now_notes = '[{},{},{},{}]'.format(
                melody[i, note_ndx],
                melody[i, note_ndx + 1],
                melody[i, note_ndx + 2],
                melody[i, note_ndx + 3]
            )
            now_chords = chord[i, j]
            now_mid = '{}|{}'.format(now_notes, now_chords)
            midi = midi + now_mid + '\n'
    file_name = file_path.split('/')[-1].split('.')[0] + '.txt'
    with open(os.path.join('testdatas/down_samples', file_name), 'w') as f:
        f.write(midi)

    return keys, melody, chord

def read_txt(pth):
    """
    :param pth: the path of the dataset which is saved as a txt file.
    :return:
    """
    keys_list = []
    melody_list = []
    chord_list = []
    with open(pth, 'r') as f:
        strs = f.readlines()
        for n, i in enumerate(strs):
            datas = i.strip('\n').split('|')
            key = datas[0]
            melody = eval(datas[1])
            datas[2] = datas[2].replace(',', ', ')
            chord = chord_str_to_list(datas[2])
            keys_list.append(keys2list(key))
            melody_list.extend(melody)
            if np.array(melody).shape[0] != 64:
                print(pth, ' ', 'Melody: ', n, ' ', np.array(melody).shape[0])
            if np.array(chord).shape[0] != 16:
                print(np.array(chord))
                print(pth, ' ', 'Chord: ', n, ' ', np.array(chord).shape[0])
            chord_list.extend(chord)

    return keys_list, melody_list, chord_list

def getDataFromMusicFile(file_path):
    if not os.path.exists(file_path):
        print('[Error] File {} does not exist!'.format(file_path))
        exit(1)
    # Handle labeled data
    np_melody_low = []
    np_melody_high = []
    np_chord = []
    np_keys = []

    keys, melody_low, chord = get_data(file_path)
    # return
    np_keys.extend(keys)

    for m in melody_low:
        melody_low_ndx = []
        melody_high_ndx = []
        for word in m:
            word = str(word)
            if word not in melody2id:
                # print('Error: {}'.format(word))
                exit(0)
            melody_low_ndx.append(melody2id[word])
            melody_high_ndx.append(notes2id[word])

        np_melody_low.append(melody_low_ndx)
        np_melody_high.append(melody_high_ndx)

    for c in chord:
        chord_ndx = np.zeros((16, ))
        for n, word in enumerate(c):
            if word not in chord2id:
                # print('Error: {}'.format(word))
                word = '[]'
            chord_ndx[n] = chord2id[word]
        np_chord.append(chord_ndx)

    start_chord = np.concatenate([[[chord2id['S']]] * len(np_chord)], axis=0)
    start_note = np.concatenate([[[notes2id['S']]] * len(np_melody_high)], axis=0)
    datas = {}
    datas['tone'] = torch.from_numpy(np.array(np_keys))
    datas['melody'] = torch.from_numpy(np.array(np_melody_low))
    datas['chord_in'] = torch.LongTensor(np.concatenate((start_chord, np_chord), axis=-1))
    datas['note_in'] = torch.LongTensor(np.concatenate((start_note, np_melody_high), axis=-1))
    datas['music_feat'] = 0
    return datas

@torch.no_grad()
def get_res(model, name, emo_pth, txt_pth):
    def obj_hook(lst):
        result = []
        for _, val in lst:
            val = np.array(val)
            result.append(val)
        return np.array(result)
    test_emotion = json.load(open(emo_pth, 'r'), object_pairs_hook=obj_hook)

    datas = getDataFromMusicFile(txt_pth)
    # return
    music_extractor = EmoFeatureExtractor(id2note=id2notes, id2chord=id2chords)

    seq_notes = []
    seq_chords = []
    
    now_section = 0
    for key in range(test_emotion.shape[0]):
        now_emo = torch.Tensor(test_emotion[key, :, :]).float().unsqueeze(0)
        if now_emo.shape[1] != 16:
            print(emo_pth, '[', key, ']','长度: ', now_emo.shape[1])
        now_datas = {
            'tone': datas['tone'][now_section, :].unsqueeze(0).to(device),
            'melody': datas['melody'][now_section, :].unsqueeze(0).to(device),
            'chord_in': datas['chord_in'][now_section, :].unsqueeze(0).to(device),
            'note_in': datas['note_in'][now_section, :].unsqueeze(0).to(device),
            'emotion': now_emo.to(device)
        }
        now_section += 1
        now_datas['note_in'] = now_datas['note_in'][:, 0].unsqueeze(0)
        # inference note
        for i in range(64):
            outs = model(now_datas)
            note_logit = outs['note'][-1, :].unsqueeze(0)
            # greedy decode
            _, note_ids = torch.topk(note_logit, k=1)
            print(note_ids)
            exit(0)
            now_datas['note_in'] = torch.cat([now_datas['note_in'], note_ids], dim=-1)
        # res
        note_ids = now_datas['note_in'][0, 1:]
        notes = []

        for nid in note_ids:
            note = id2notes[str(nid.item())]
            if note in ['S', 'E', 'P']:
                note = '0'
            note = eval(note)
            notes.append(note)

        now_notes = []
        for i in range(0, len(notes), 65):
            now_notes.extend(notes[i: i + 64])
        seq_notes.append(now_notes)

        chord_logit = outs['chord']
        chords = []
        _, chord_ids = torch.topk(chord_logit, k=1)

        for cid in chord_ids:
            chord = id2chords[str(cid.item())]
            if chord in ['S', 'E', 'P']:
                chord = '[]'
            chord = eval(chord)
            chords.append(chord)
        
        now_chords = []
        for i in range(0, len(chords), 17):
            now_chords.extend(chords[i: i + 16])
        seq_chords.append(now_chords)

    res = {'notes': seq_notes, 'chords': seq_chords}
    t_name = t_pth.split('/')[-1].split('.')[0]
    e_name = e_pth.split('/')[-1].split('.')[0]
    saved_path = 'results/{}_{}'.format(t_name, e_name)
    if not os.path.exists(saved_path):
        os.mkdir(saved_path)

    with open(os.path.join(saved_path, '{}.json'.format(name)), 'w') as f:
        f.write(json.dumps(res))

if __name__ == '__main__':       
    access = Access().to(device)
    access_ckpt = torch.load('modelzoo/access49.ckpt', map_location=device)
    access.load_state_dict(access_ckpt)
    for p in access.parameters():
        p.requires_grad = False

    song_root = 'testdatas/hotsongs'
    emo_root = 'testdatas/emo_seq'
    
    txt_pths = [os.path.join(song_root, f) for f in os.listdir(song_root)]
    emo_pths = [os.path.join(emo_root, f) for f in os.listdir(emo_root)]
    models = {'access': access}

    for t_pth in txt_pths:
        for e_pth in emo_pths:
            print(t_pth, e_pth)
            if t_pth.split('/')[-1] == '.DS_Store' or e_pth.split('/')[-1] == '.DS_Store':
                continue
            t_name = t_pth.split('/')[-1].split('.')[0]
            e_name = e_pth.split('/')[-1].split('.')[0]
            saved_path = 'results/{}_{}'.format(t_name, e_name)
    
            for name in models.keys():
                file = os.path.join(saved_path, '{}.json'.format(name))
                if os.path.exists(file):
                    print('Exist: {}'.format(file))
                    continue
                get_res(models[name], name, e_pth, t_pth)
            break
