import json
import torch
import os
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data.dataset import random_split
from config import Config
from tqdm import tqdm
from torch.utils.data import DataLoader
from data.musicDatasetFast import AiMusicDatasetEmo
from models.emo_model import EmoModelPure

if __name__ == '__main__':
    # full_dataset = AiMusicDatasetEmo('dataset/label_seq_emo.npz', step=1)
    # total = 0
    # wrong = 0
    # for d in full_dataset:
    #     emotion = d['emotion']
    #     emotion = emotion.view(-1, 64, 2)
    #     for i in range(emotion.shape[0]):
    #         emotion_split = emotion[i, :, :]
    #         emotion_split:torch.Tensor = emotion_split - emotion_split[0, :]
    #         if torch.unique(emotion_split).shape[0] > 2:
    #             wrong += (torch.unique(emotion_split).shape[0] - 1) 
    #     total += emotion.shape[0]
    
    # print(100 * wrong / total)
    notes2id = json.load(open('dataset/enhance_notes_vocab.json', 'r'))
    melody2id = json.load(open('dataset/enhance_melody_vocab.json', 'r'))
    chord2id = json.load(open('dataset/enhance_chord_vocab.json', 'r'))
    
    id2notes = {}
    id2chords = {}
    
    for key in notes2id:
        id2notes[notes2id[key]] = key

    for key in chord2id:
        id2chords[chord2id[key]] = key
    
    
    with open('dataset/enhance_id2note.json', 'w') as f:
        f.write(json.dumps(id2notes))
    
    with open('dataset/enhance_id2chord.json', 'w') as f:
        f.write(json.dumps(id2chords))
    # full_dataset = AiMusicDatasetEmo('dataset/label_seq_emo.npz', step=1)
    # total = 0
    # wrong = 0
    # for d in full_dataset:
    #     emotion = d['emotion']
    #     emotion = emotion.view(-1, 64, 2)
    #     for i in range(emotion.shape[0]):
    #         emotion_split = emotion[i, :, :]
    #         emotion_split:torch.Tensor = emotion_split - emotion_split[0, :]
    #         if torch.unique(emotion_split).shape[0] > 2:
    #             wrong += (torch.unique(emotion_split).shape[0] - 1) 
    #     total += emotion.shape[0]
    
    # print(100 * wrong / total)