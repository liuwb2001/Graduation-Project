import json
import os
import torch
import numpy as np
import math
from models.muthera_dual import DualMuThera
from utils import keys2list
from models.music_feature_extractor_ml import EmoFeatureExtractor

id2notes = json.load(open('dataset/id2note.json', 'r'))
id2chords = json.load(open('dataset/id2chord.json', 'r'))

notes2id = json.load(open('dataset/notes_vocab.json', 'r'))
melody2id = json.load(open('dataset/melody_vocab.json', 'r'))
chord2id = json.load(open('dataset/chord_vocab.json', 'r'))

device = 'mps'

def chord_str_to_list(chord_str):
    chord_lst = []
    full_str = chord_str.lstrip('[[').rstrip(']]').split('], [')
    sentence = []
    for ele in full_str:
        ele = '[' + ele + ']'
        sentence.append(ele)
    chord_lst.extend(sentence)
    return chord_lst

def get_data(file_path):
    keys, melody, chord = read_txt(file_path)
    # if np.array(melody).shape[0] != 15 * 64:
    #     print('Melody {}: '.format(np.array(melody).shape[0]), file_path)
    # elif np.array(chord).shape[0] != 240:
    #     print('Chord: {}'.format(np.array(chord).shape[0]), file_path)
    # return None, None, None

    melody = np.array(melody).reshape(15, -1)
    chord = np.array(chord).reshape(15, -1)
    keys = np.array(keys)
    # # 60小节
    # section_num = 60
    # num_row = section_num // 4
    # melody_num = section_num * 16
    # chord_num = section_num * 4
    # tile_num = math.ceil(melody_num / melody.shape[0])
    midi = ''
    for i in range(chord.shape[0]):
        for j in range(chord.shape[1]):
            note_ndx = j * 4
            now_notes = '[{},{},{},{}]'.format(
                melody[i, note_ndx],
                melody[i, note_ndx + 1],
                melody[i, note_ndx + 2],
                melody[i, note_ndx + 3]
            )
            now_chords = chord[i, j]
            now_mid = '{}|{}'.format(now_notes, now_chords)
            midi = midi + now_mid + '\n'
    file_name =  'recommend.txt'
    music_name = file_path.split('/')[-1].split('.')[0]
    save_path = '/Users/male/Desktop/推荐方法/{}_突变情感序列cxy'.format(music_name)
    if not os.path.exists(save_path):
        os.mkdir(save_path)

    with open(os.path.join(save_path, file_name), 'w') as f:
        f.write(midi)

    return keys, melody, chord

def read_txt(pth):
    """
    :param pth: the path of the dataset which is saved as a txt file.
    :return:
    """
    keys_list = []
    melody_list = []
    chord_list = []
    with open(pth, 'r') as f:
        strs = f.readlines()
        for n, i in enumerate(strs):
            datas = i.strip('\n').split('|')
            key = datas[0]
            melody = eval(datas[1])
            datas[2] = datas[2].replace(',', ', ')
            chord = chord_str_to_list(datas[2])
            keys_list.append(keys2list(key))
            melody_list.extend(melody)
            if np.array(melody).shape[0] != 64:
                print(pth, ' ', 'Melody: ', n, ' ', np.array(melody).shape[0])
            if np.array(chord).shape[0] != 16:
                print(pth, ' ', 'Chord: ', n, ' ', np.array(chord).shape[0])
            chord_list.extend(chord)

    return keys_list, melody_list, chord_list

if __name__ == '__main__':
    # all txt in dir
    for f in os.listdir('/Users/male/Desktop/推荐方法'):
        if f.endswith('.txt'):
            f_path = os.path.join('/Users/male/Desktop/推荐方法', f)
            get_data(f_path)
