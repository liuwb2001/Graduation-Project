import json
import os
import torch
from models.muthera_dual import DualMuThera
from utils_low import getDataFromMusicFile
from models.music_feature_extractor_ml import EmoFeatureExtractor

id2notes = json.load(open('dataset/enhance_id2note.json', 'r'))
id2chords = json.load(open('dataset/enhance_id2chord.json', 'r'))

notes2id = json.load(open('dataset/enhance_notes_vocab.json', 'r'))
melody2id = json.load(open('dataset/enhance_melody_vocab.json', 'r'))
chord2id = json.load(open('dataset/enhance_chord_vocab.json', 'r'))

device = 'mps'

@torch.no_grad()
def get_res(model, name):
    test_emotion = json.load(open('test_data.json', 'r'))
    datas = getDataFromMusicFile('testdatas/uf_1141.txt')
    music_extractor = EmoFeatureExtractor()
    batch_size = datas['note_in'].shape[0]

    seq_notes = []
    seq_chords = []
    pre_outs = None

    for key in test_emotion:
        print(key)
        now_emo = torch.Tensor(test_emotion[key]).float().unsqueeze(0).tile((batch_size, 1, 1))
        now_datas = {
            'tone': datas['tone'].to(device),
            'melody': datas['melody'].to(device),
            'chord_in': datas['chord_in'].to(device),
            'note_in': datas['note_in'].to(device),
            'emotion': now_emo.to(device)
        }
    
        now_datas['chord_in'][:, 1:] = 0
        now_datas['note_in'][:, 1:] = 0
        
        # inference note
        for i in range(64):
            outs = model(now_datas, pre_outs)
            note_logit = outs['note'].view(batch_size, 65, -1)[:, i, :]
            _, note_ids = torch.topk(note_logit, k=1)
            for n, nid in enumerate(note_ids):
                now_datas['note_in'][n, i + 1] = nid
        # outs = model(now_datas, pre_outs)
        # res
        note_logit = outs['note']
        notes = []
        _, note_ids = torch.topk(note_logit, k=1)
        for nid in note_ids:
            note = id2notes[str(nid.item())]
            if note in ['S', 'E', 'P']:
                note = '0'
            note = eval(note)
            notes.append(note)
        
        now_notes = []
        for i in range(0, len(notes), 65):
            now_notes.extend(notes[i: i + 64])
        seq_notes.append(now_notes)

        chord_logit = outs['chord']
        chords = []
        _, chord_ids = torch.topk(chord_logit, k=1)

        for cid in chord_ids:
            chord = id2chords[str(cid.item())]
            if chord in ['S', 'E', 'P']:
                chord = '[]'
            chord = eval(chord)
            chords.append(chord)
        
        now_chords = []
        for i in range(0, len(chords), 17):
            now_chords.extend(chords[i: i + 16])
        seq_chords.append(now_chords)

        # get music features
        pre_outs = outs
        pre_outs['music_feat'] = music_extractor(outs, contain_S_E=True).to(device)

    res = {'notes': seq_notes, 'chords': seq_chords}
    saved_path = 'results/{}'.format(name)
    if not os.path.exists(saved_path):
        os.mkdir(saved_path)

    with open(os.path.join(saved_path, '{}.json'.format(name)), 'w') as f:
        f.write(json.dumps(res))

if __name__ == '__main__':
    median = DualMuThera(emo_fusion_type='median').to(device)
    median_ckpt = torch.load('modelzoo/low_median', map_location=device)
    median.load_state_dict(median_ckpt)
    
    replace = DualMuThera(emo_fusion_type='replace').to(device)
    replace_ckpt = torch.load('modelzoo/low_replace', map_location=device)
    replace.load_state_dict(replace_ckpt)

    concat = DualMuThera(emo_fusion_type='concat').to(device)
    concat_ckpt = torch.load('modelzoo/low_concat', map_location=device)
    concat.load_state_dict(concat_ckpt)
    
    get_res(median, 'median_uf1141_enhance')
    get_res(concat, 'concat_uf1141_enhance')
    get_res(replace, 'replace_uf1141_enhance')
