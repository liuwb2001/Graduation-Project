import torch
import torch.nn as nn
import torch.nn.functional as F
from config import Config



'''
input_size 输入数据的特征维数,通常就是embedding_dim(词向量的维度)
hidden_size LSTM中隐层的维度
num_layers 循环神经网络的层数
bias 用不用偏置,default=True
batch_first 这个要注意,通常我们输入的数据shape=(batch_size,seq_length,embedding_dim),而batch_first默认是False,所以我们的输入数据最好送进LSTM之前将batch_size与seq_length这两个维度调换
dropout 默认是0,代表不用dropout
bidirectional默认是false,代表不用双向LSTM
'''

def Embedding(num_embeddings, embedding_dim, padding_idx=None):
    m = nn.Embedding(num_embeddings, embedding_dim, padding_idx=padding_idx)  # param1:词嵌入字典大小； param2：每个词嵌入单词的大小
    # 正态分布初始化；e.g.,torch.nn.init.normal_(tensor, mean=0, std=1) 使值服从正态分布N(mean, std)，默认值为0，1
    nn.init.normal_(m.weight, mean=0, std=embedding_dim ** -0.5)
    if padding_idx is not None:
        nn.init.constant_(m.weight[padding_idx], 0)
    return m


class mLSTM(nn.Module):
    def __init__(
            self, d_model=256, 
            chord_yaml='config_m2c.yaml', 
            melody_yaml='config_n2m.yaml',
        ):
        super(mLSTM, self).__init__()
        # Melody to Chord
        args_chord = Config(chord_yaml)
        args_melody = Config(melody_yaml)
        self.embed_chord = Embedding(args_chord.tgt_vocab_size, args_chord.d_model)
        self.embed_note = Embedding(args_melody.tgt_vocab_size, args_melody.d_model)
        
        self.chord_generator = nn.LSTM(
            input_size=d_model * 2,
            hidden_size=4096,
            num_layers=1,
        )
        # Notes to Melody
        self.melody_generator = nn.LSTM(
            input_size=d_model * 2,
            hidden_size=4096,
            num_layers=1,
        )
        # Emotion Embedding
        self.emotion_embed = nn.Linear(2, d_model)
        self.out_chord = nn.Linear(4096, args_chord.tgt_vocab_size)
        self.out_note = nn.Linear(4096, args_melody.tgt_vocab_size)

    def forward(self, now_input):
        cur_VA = now_input['emotion'].float().mean(dim=1)
        emotions = self.emotion_embed(cur_VA)
        emotions = emotions.unsqueeze(1)

        chords = self.embed_chord(now_input['chord_in'])
        notes = self.embed_note(now_input['note_in'])

        len_chord = chords.size(1)
        len_notes = notes.size(1)
        chord_emo = torch.tile(emotions, dims=(1, len_chord, 1))
        note_emo = torch.tile(emotions, dims=(1, len_notes, 1))

        chords = torch.cat((chords, chord_emo), dim=-1)
        notes = torch.cat((notes, note_emo), dim=-1)
        

        # 生成旋律Melody 和弦Chord
        generate_chord = []
        last_hid = False
        for i in range(len_chord):
            if last_hid:
                chord_logit, h = self.chord_generator(chords[:, i, :].unsqueeze(1), h)
            else:
                last_hid = True
                chord_logit, h = self.chord_generator(chords[:, i, :].unsqueeze(1))
            generate_chord.append(chord_logit)
        generate_chord = torch.stack(generate_chord, dim=1).squeeze(2)

        generate_note = []
        last_hid = False
        for i in range(len_notes):
            if last_hid:
                note_logit, h = self.melody_generator(notes[:, i, :].unsqueeze(1), h)
            else:
                last_hid = True
                note_logit, h = self.melody_generator(notes[:, i, :].unsqueeze(1))
            generate_note.append(note_logit)
        generate_note = torch.stack(generate_note, dim=1).squeeze(2)
        
        generate_chord = generate_chord.view(generate_chord.shape[0] * generate_chord.shape[1], -1)
        generate_note = generate_note.view(generate_note.shape[0] * generate_note.shape[1], -1)

        generate_chord = self.out_chord(generate_chord)
        generate_note = self.out_note(generate_note)

        '''
        返回生成和弦、旋律, 当前情感(作为下一次计算的pre_emotion)
        '''
        out = {
            'music_feat': now_input['music_feat'],
            'chord_true': now_input['chord_in'][:, 1:],
            'note_true': now_input['note_in'][:, 1:],
            'tone': now_input['tone'],
            'chord': generate_chord,
            'note': generate_note,
            # 与下一时刻的predict_VA计算损失,因为predict_VA是预测上一时刻的VA
            'emotion': cur_VA
        }
        return out
