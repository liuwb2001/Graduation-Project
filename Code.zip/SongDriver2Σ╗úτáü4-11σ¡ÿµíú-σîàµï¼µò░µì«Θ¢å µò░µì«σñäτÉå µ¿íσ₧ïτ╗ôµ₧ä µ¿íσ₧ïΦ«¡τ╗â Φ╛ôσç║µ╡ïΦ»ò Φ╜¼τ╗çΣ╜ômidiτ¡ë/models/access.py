import torch
import torch.nn as nn
import math
from config import Config
from models.muthera_dual import DualTransformer


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=256):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        r"""Inputs of forward function
        Args:
            x: the sequence fed to the positional encoder model (required).
        Shape:
            x: [sequence length, batch size, embed dim]
            output: [sequence length, batch size, embed dim]
        Examples:
            >>> output = pos_encoder(x)
        """
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

class Access(nn.Module):
    def __init__(
            self, chord_yaml='config_m2c.yaml', 
            melody_yaml='config_n2m.yaml', 
            d_model=512, va_dim=16
        ):
        super(Access, self).__init__()
        args_chord = Config(chord_yaml)
        args_melody = Config(melody_yaml)
        # Melody to Chord
        self.dual_generator = DualTransformer(args_melody)
        # Emotion Embedding
        self.emotion_embed = nn.Linear(2, d_model)
        self.pos_emotion_embed = PositionalEncoding(d_model)
        self.emotion_encoder = nn.TransformerEncoder(
            encoder_layer=nn.TransformerEncoderLayer(d_model, 2),
            num_layers=4,
        )

    def forward(self, now_input):
        '''
        4 musical features
        B X 256 chord_color
        B X 256 rhy_patn
        B X (4 + 2) struct
        B X (3 + 3) contour
        '''
        # Emotion Embedding
        cur_VA = now_input['emotion'].float()
        emotions = self.pos_emotion_embed(self.emotion_embed(cur_VA))
        emotions = self.emotion_encoder(emotions).mean(dim=1)
        # 生成旋律Melody 和弦Chord
        generate_note, generate_chord = self.dual_generator(now_input['melody'], now_input['note_in'], emotions)
        
        '''
        返回生成和弦、旋律, 当前情感(作为下一次计算的pre_emotion)
        '''
        out = {
            # 'music_feat': now_input['music_feat'],
            'tone': now_input['tone'],
            'chord': generate_chord,
            'chord_in': now_input['chord_in'],
            'note': generate_note,
            'note_in':  now_input['note_in'],
            # 与下一时刻的predict_VA计算损失，因为predict_VA是预测上一时刻的VA
            'emotion': cur_VA
        }
        return out
