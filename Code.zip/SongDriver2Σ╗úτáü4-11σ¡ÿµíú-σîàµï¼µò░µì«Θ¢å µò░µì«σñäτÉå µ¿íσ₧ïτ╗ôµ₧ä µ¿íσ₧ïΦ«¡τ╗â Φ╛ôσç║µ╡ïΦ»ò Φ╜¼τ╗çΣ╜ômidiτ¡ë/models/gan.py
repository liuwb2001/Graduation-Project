import torch
import torch.nn as nn
import math
from config import Config
from models.muthera_dual import DualTransformer


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=256):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        r"""Inputs of forward function
        Args:
            x: the sequence fed to the positional encoder model (required).
        Shape:
            x: [sequence length, batch size, embed dim]
            output: [sequence length, batch size, embed dim]
        Examples:
            >>> output = pos_encoder(x)
        """
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

class Generator(nn.Module):
    def __init__(
            self, chord_yaml='config_m2c.yaml', 
            melody_yaml='config_n2m.yaml', 
            d_model=512, va_dim=16
        ):
        super(Generator, self).__init__()
        args_chord = Config(chord_yaml)
        args_melody = Config(melody_yaml)
        # Melody to Chord
        self.dual_generator = DualTransformer(args_melody)
        # Emotion Embedding
        self.emotion_embed = nn.Linear(2, d_model)
        self.pos_emotion_embed = PositionalEncoding(d_model)
        self.emotion_encoder = nn.TransformerEncoder(
            encoder_layer=nn.TransformerEncoderLayer(d_model, 2),
            num_layers=4,
        )

    def forward(self, now_input):
        '''
        4 musical features
        B X 256 chord_color
        B X 256 rhy_patn
        B X (4 + 2) struct
        B X (3 + 3) contour
        '''
        # Emotion Embedding
        cur_VA = now_input['emotion'].float()
        emotions = self.pos_emotion_embed(self.emotion_embed(cur_VA))
        emotions = self.emotion_encoder(emotions).mean(dim=1)
        # 生成旋律Melody 和弦Chord
        generate_note, generate_chord = self.dual_generator(now_input['melody'], now_input['note_in'], emotions)
        
        '''
        返回生成和弦、旋律, 当前情感(作为下一次计算的pre_emotion)
        '''
        out = {
            'chord': generate_chord,
            'note': generate_note,
            # 与下一时刻的predict_VA计算损失，因为predict_VA是预测上一时刻的VA
            'emotion': cur_VA
        }
        return out


class Discriminator(nn.Module):
    def __init__(
            self, chord_yaml='config_m2c.yaml', 
            melody_yaml='config_n2m.yaml', 
            embed_dim=512
        ):
        super(Discriminator, self).__init__()
        self.pos_note_embed = PositionalEncoding(embed_dim)
        self.note_embed = nn.Embedding(113, embed_dim)
        self.melody_encoder = nn.TransformerEncoder(
            encoder_layer=nn.TransformerEncoderLayer(embed_dim, 2),
            num_layers=4,
        )
        
        self.pos_chord_embed = PositionalEncoding(embed_dim)
        self.chord_embed = nn.Embedding(17327, embed_dim)
        self.chord_encoder = nn.TransformerEncoder(
            encoder_layer=nn.TransformerEncoderLayer(embed_dim, 2),
            num_layers=4,
        )
        
        self.melody_discriminator = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, 1),
            nn.Sigmoid(),
        )
        
        self.chord_discriminator = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, 1),
            nn.Sigmoid(),
        )

    def forward(self, now_input):
        note = self.pos_note_embed(self.note_embed(now_input['note']))
        chord = self.pos_chord_embed(self.chord_embed(now_input['chord']))
        
        note = self.melody_encoder(note).mean(dim=1)
        chord = self.chord_encoder(chord).mean(dim=1)     
   
        d_chord = self.chord_discriminator(chord)
        d_melody = self.melody_discriminator(note)

        return d_chord, d_melody

class GAN(nn.Module):
    def __init__(
            self, chord_yaml='config_m2c.yaml', 
            melody_yaml='config_n2m.yaml', 
            d_model=512, va_dim=16
        ):
        super(GAN, self).__init__()
        self.generator = Generator(chord_yaml, melody_yaml, d_model, va_dim)
        self.discriminator = Discriminator(chord_yaml, melody_yaml, d_model)

    def forward(self, now_input):
        generate_content = self.generator(now_input)
        batch_size = now_input['emotion'].shape[0]
        # 生成的和弦、旋律、情感
        g_chord = torch.topk(generate_content['chord'], 1, dim=-1)[1].squeeze(-1)
        g_chord = g_chord.view(batch_size, -1)[:, :-1]
        g_note = torch.topk(generate_content['note'], 1, dim=-1)[1].squeeze(-1)
        g_note = g_note.view(batch_size, -1)[:, :-1]
        
        d_true_chord, d_true_melody = self.discriminator({
            'chord': now_input['chord_in'][:, 1:],
            'note': now_input['note_in'][:, 1:],
        })

        d_fake_chord, d_fake_melody = self.discriminator({
            'chord': g_chord,
            'note': g_note,
        })
        return generate_content, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord)