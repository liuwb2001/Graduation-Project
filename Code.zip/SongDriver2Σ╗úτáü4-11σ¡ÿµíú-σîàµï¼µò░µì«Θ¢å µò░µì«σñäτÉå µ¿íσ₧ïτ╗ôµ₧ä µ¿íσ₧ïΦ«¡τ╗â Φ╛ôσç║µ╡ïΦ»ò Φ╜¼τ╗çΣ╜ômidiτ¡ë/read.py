import json
import numpy as np

def open_results_file(file_path):
    with open(file_path) as f:
        res = json.load(f)
    notes = np.array(res['notes']).reshape((-1, 64))
    chords = np.array(res['chords']).reshape((-1, 16))
    return notes, chords

notes, chords = open_results_file('results/median_chongerfei/median_chongerfei.json')
print(notes.shape)
print(chords.shape)