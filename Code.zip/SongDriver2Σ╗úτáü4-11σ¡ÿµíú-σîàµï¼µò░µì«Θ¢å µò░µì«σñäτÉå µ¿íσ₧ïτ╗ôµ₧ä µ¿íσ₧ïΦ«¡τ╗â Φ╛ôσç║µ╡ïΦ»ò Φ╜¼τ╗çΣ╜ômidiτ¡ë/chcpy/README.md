# 利用织体生成midi的方法：
将需要转换的文本文件放入/outputs/chordplay (名字任意，txt结尾，位置随便放就行，系统会自动识别)，然后执行/chcpy/tool/chordPlayer进行转换  
如要更换织体，请在/chcpy/tool/chordPlayer.cpp中修改lua文件路径
# midi转wav方法：
先安装fluidsynth  
`sudo apt install fluidsynth`  
然后进行转换  
`/usr/bin/fluidsynth -ni 音源.sf2 输入.mid -F 输出.wav -r 44100`
