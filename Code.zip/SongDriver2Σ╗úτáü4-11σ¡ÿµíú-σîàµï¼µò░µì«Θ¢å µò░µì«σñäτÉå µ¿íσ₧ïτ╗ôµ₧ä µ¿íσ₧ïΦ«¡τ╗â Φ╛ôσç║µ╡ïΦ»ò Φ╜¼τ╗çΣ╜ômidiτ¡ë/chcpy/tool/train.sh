./listBuilder
./dict_builder
./hmm_train
./chordtime_builder
./bayes_train