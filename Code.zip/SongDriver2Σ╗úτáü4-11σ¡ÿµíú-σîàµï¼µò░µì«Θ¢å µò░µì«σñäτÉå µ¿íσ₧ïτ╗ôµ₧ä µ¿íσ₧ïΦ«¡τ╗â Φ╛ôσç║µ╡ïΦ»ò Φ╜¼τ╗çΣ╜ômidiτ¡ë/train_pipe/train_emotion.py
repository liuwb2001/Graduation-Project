import json
import torch
import os
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data.dataset import random_split
from config import Config
from tqdm import tqdm
from torch.utils.data import DataLoader
from data.musicDatasetFast import AiMusicDatasetEmo
from models.emo_model import EmoModel


SEED = 3547
torch.manual_seed(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

NAME = 'EmoModel'
LOG_PATH = 'log/{}'.format(NAME)
CKPT_PATH = 'modelzoo/{}'.format(NAME)

if not os.path.exists(LOG_PATH):
    os.mkdir(LOG_PATH)
    
if not os.path.exists(CKPT_PATH):
    os.mkdir(CKPT_PATH)


def pipeline(model, train_loader, eval_loader, test_loader, args, ckpt_pth=None):
    model = model.to(device)
    start_epoch = 0
    if ckpt_pth:
        ckpt = torch.load(ckpt_pth, map_location=device)
        model.load_state_dict(ckpt)
        start_epoch = int(ckpt_pth.split('/')[-1].split('.')[0]) + 1
        print('[Resume] load ckpt {}'.format(ckpt_pth))

    optimizer = torch.optim.Adam(model.parameters(), lr=3.5e-4)
    scheduler = CosineAnnealingLR(optimizer=optimizer, T_max=args.epoch, eta_min=1e-5)
    postfix = {'running_loss': 0.0}

    for epoch in range(start_epoch, start_epoch + args.epoch):
        tqdm_train = tqdm(train_loader, desc='Training (epoch #{})'.format(epoch))
        train_loss = 0
        pred_right = 0
        pred_n = 0
        n = 0
        # train
        for batch in tqdm_train:
            # To device
            for key in batch:
                batch[key] = batch[key].to(device)
            # Load data
            batch_size = batch['music_feat'].shape[0]
            pred_va, _ = model(batch)
            trg_va = batch['emotion']
            loss = F.mse_loss(pred_va[:, :, 0], trg_va[:, :, 0]) \
                + F.mse_loss(pred_va[:, :, 1], trg_va[:, :, 1])
            # Record Loss
            dist = torch.sqrt(torch.sum((pred_va - trg_va) ** 2, dim=-1))
            seq_len = dist.shape[-1]
            pred_right += (dist <= 0.5).sum()
            pred_n += batch_size * seq_len

            train_loss += loss.item() * batch_size
            n += batch_size
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            postfix['running_loss'] += (loss.item() - postfix['running_loss']) / (epoch + 1)
            tqdm_train.set_postfix(postfix)
        scheduler.step()
        # evaluate
        eval_loss = evaluate(model, eval_loader)
        # test
        va_acc = test(model, test_loader)
        res_json = {
            'epoch': epoch,
            'train_loss': train_loss / n,
            'eval_loss': eval_loss,
            'test_accuracy_va': va_acc.item(),
            'train_accuracy_va': (pred_right / pred_n).item(),
        }
        with open('{}/epochs.json'.format(LOG_PATH), 'a') as f:
            res = json.dumps(res_json)
            f.write(res + '\n')
        # scheduler.step()
        torch.save({
            'model': model.state_dict(),
            'scheduler': scheduler.state_dict(),
            'epoch': epoch,
        }, f'{CKPT_PATH}/{epoch}.ckpt')

@torch.no_grad()
def evaluate(model, loader):
    model = model.to(device)
    eval_loss = 0

    n = 0
    pre_output = None
    for batch in tqdm(loader):
         # To device
        for key in batch:
            batch[key] = batch[key].to(device)
        # Load data
        batch_size = batch['melody'].shape[0]
        pred_va, _ = model(batch)
        # emotion prediction loss
        trg_va = batch['emotion']
        loss = F.mse_loss(pred_va[:, :, 0], trg_va[:, :, 0]) \
                + F.mse_loss(pred_va[:, :, 1], trg_va[:, :, 1])
        eval_loss += loss.item() * batch_size
        n += batch_size
        # record out for T+1

    return eval_loss / n

@torch.no_grad()
def test(model, loader):
    global device
    pred_n = 0
    pred_right = 0
    pre_output = None
    for batch in tqdm(loader):
         # To device
        for key in batch:
            batch[key] = batch[key].to(device)
        # Load data
        batch_size = batch['melody'].shape[0]
        pred_va, _ = model(batch)
        # record out for T+1
        trg_va = batch['emotion']
        dist = torch.sqrt(torch.sum((pred_va - trg_va) ** 2, dim=-1))
        seq_len = dist.shape[-1]
        pred_right += (dist <= 0.5).sum()
        pred_n += batch_size * seq_len

    return pred_right / pred_n


if __name__ == '__main__':
    # print(f"batch_size:{args.batch_size}")
    args = Config('config_muthera.yaml')
    args.epoch = 50
    full_dataset = AiMusicDatasetEmo('dataset/labeled20230313.npz')
    train_set, test_set, eval_set = random_split(full_dataset, [90127, 1000, 1000], generator=torch.Generator().manual_seed(SEED))

    train_loader = DataLoader(train_set, 64, shuffle=True, drop_last=False)
    eval_loader = DataLoader(eval_set, 64, shuffle=False, drop_last=False)
    test_loader = DataLoader(test_set, 64, shuffle=False, drop_last=False)
    
    print('Dataloader done.')

    model = EmoModel(va_dim=16).to(device)
    pipeline(model, train_loader, eval_loader, test_loader, args)
