import torch
import numpy as np
import json
from tqdm import tqdm
# from data.musicDatasetFast import AiMusicDataset
from utils import read_txt

'''
[16种情感, 原TXT行数, 256]
[16种情感, 原TXT行数, 16]
'''


id2notes = json.load(open('dataset/id2note.json', 'r'))
id2chords = json.load(open('dataset/id2chord.json', 'r'))
    
notes2id = json.load(open('dataset/notes_vocab.json', 'r'))
melody2id = json.load(open('dataset/melody_vocab.json', 'r'))
chord2id = json.load(open('dataset/chord_vocab.json', 'r'))

def open_results_file(file_path):
    with open(file_path) as f:
        res = json.load(f)
    notes = np.array(res['notes']).reshape((16, -1, 256))
    chords = np.array(res['chords']).reshape((16, -1, 16))
    return notes, chords

def check():
    labeled = AiMusicDataset('dataset/labeled20230313.npz', True)
    unlabeled = AiMusicDataset('dataset/unlabeled20230313.npz', False)
    
    for d in labeled:
        melody = d['melody']
        note = d['note_in'][1:]
        chord = d['chord_in'][1:].numpy().tolist()
        for n, c in enumerate(chord):
            chord[n] = id2chords[str(c)]
        print(chord)
        # compare_res = torch.all(melody == note).item()
        # if not compare_res:
        #     print('Haha {}'.format(compare_res))
        #     exit(0)

    for d in tqdm(unlabeled):
        melody = d['melody']
        note = d['note_in'][1:]
        chord = d['chord_in'][1:].numpy().tolist()
        for n, c in enumerate(chord):
            chord[n] = id2chords[str(c)]
        print(chord)
        # compare_res = torch.all(melody == note).item()
        # if not compare_res:
        #     print('Haha {}'.format(compare_res))
        #     exit(0)
    exit(0)

if __name__ == '__main__':
    # check()
    from data.musicDatasetEnhance import AiMusicDataset
    d = AiMusicDataset('dataset/enhance_labeled.npz')
    for i in d:
        if i['melody'].shape[-1] != 64:
            print(i['melody'].shape)
    exit(0)
    file = 'results/median/median.json'
    notes, chords = open_results_file(file)
    # read ground true
    _, _, _, gt_melody_high, gt_chord, _, _ = read_txt('uf_1141.txt')
    # 2d-high melody to 1d
    melody_high_1d = []
    for melodys in gt_melody_high:
        tmp = []
        for m in melodys:
            tmp.extend([m[0]] * m[1])
        melody_high_1d.append(tmp)  
    # to numpy
    gt_melody_high = np.array(melody_high_1d)
    gt_chord = np.array(gt_chord)
    
    # check
    print('(GT): {}'.format(gt_melody_high[3, :]))
    for i in range(16):
        print('({}): {}'.format(i, notes[i, 3, :]))
        
        
    print('(GT): {}'.format(gt_chord[3, :]))
    for i in range(16):
        print('({}): {}'.format(i, chords[i, 3, :].tolist()))