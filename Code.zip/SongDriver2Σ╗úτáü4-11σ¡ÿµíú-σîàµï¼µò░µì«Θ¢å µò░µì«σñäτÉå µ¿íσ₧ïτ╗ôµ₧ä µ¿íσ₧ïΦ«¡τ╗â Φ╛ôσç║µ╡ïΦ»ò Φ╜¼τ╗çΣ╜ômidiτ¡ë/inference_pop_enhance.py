import json
import os
import torch
import numpy as np
import math
from models.muthera_dual import DualMuThera
from utils import keys2list
from models.music_feature_extractor_ml import EmoFeatureExtractor

id2notes = json.load(open('dataset/enhance_id2note.json', 'r'))
id2chords = json.load(open('dataset/enhance_id2chord.json', 'r'))

notes2id = json.load(open('dataset/enhance_notes_vocab.json', 'r'))
melody2id = json.load(open('dataset/enhance_melody_vocab.json', 'r'))
chord2id = json.load(open('dataset/enhance_chord_vocab.json', 'r'))


device = 'mps'

def keys2list(keystr):
    def key_2_ref_chord(key):
        if key == 'C.MAJOR':
            ans = [0, 4, 7]
        elif key == 'D.MAJOR':
            ans = [2, 6, 9]
        elif key == 'E.MAJOR':
            ans = [4, 8, 11]
        elif key == 'F.MAJOR':
            ans = [5, 9, 12]
        elif key == 'G.MAJOR':
            ans = [7, 11, 14]
        elif key == 'A.MAJOR':
            ans = [9, 13, 16]
        elif key == 'B.MAJOR':
            ans = [11, 15, 18]
        elif key == 'C.MINOR':
            ans = [0, 3, 7]
        elif key == 'D.MINOR':
            ans = [2, 5, 9]
        elif key == 'E.MINOR':
            ans = [4, 7, 11]
        elif key == 'F.MINOR':
            ans = [5, 8, 12]
        elif key == 'G.MINOR':
            ans = [7, 10, 14]
        elif key == 'A.MINOR':
            ans = [9, 12, 16]
        elif key == 'B.MINOR':
            ans = [11, 14, 18]
        else:
            ans = [0, 4, 7]
        return ans
    keystr = keystr[2:-2]
    keystr = keystr.split('),(')
    keys = []
    for t in keystr:
        pair = t.split(',')
        keys.append((pair[0], int(pair[1])))
    keys_high_sampled = []
    for t in keys:
        keys_high_sampled.extend([t[0]] * t[1])
    keys_1d = keys_high_sampled[::16]
    tones = []
    for i in range(len(keys_1d)):
        tones.append(key_2_ref_chord(keys_1d[i]))
    return tones

def chord_str_to_list(chord_str):
    chord_lst = []
    full_str = chord_str.lstrip('[[').rstrip(']]').split('], [')
    sentence = []
    for ele in full_str:
        ele = '[' + ele + ']'
        sentence.append(ele)
    chord_lst.extend(sentence)
    return chord_lst

def get_data(file_path):
    keys, melody, chord = read_txt(file_path)
    melody = np.array(melody)
    chord = np.array(chord)
    keys = np.array(keys)
    # 60小节
    section_num = 60
    num_row = section_num // 4
    melody_num = section_num * 16
    chord_num = section_num * 4
    
    tile_num = math.ceil(melody_num / melody.shape[0])

    keys = np.tile(keys[0, :], (num_row, 1, 1))
    melody = np.tile(melody, tile_num)[:melody_num].reshape(num_row, 64)
    chord = np.tile(chord, tile_num)[:chord_num].reshape(num_row, 16)
    return keys, melody, chord

def read_txt(pth):
    keys_list = []
    melody_list = []
    chord_list = []
    with open(pth, 'r') as f:
        strs = f.readlines()
        for n, i in enumerate(strs):
            datas = i.strip('\n').split('|')
            key = datas[0].split('/')[1].split(' ')[-1]
            key = '[({}.MAJOR,256)]'.format(key.upper())
            enhance_melody = []
            enhance_chords = []
            chord = chord_str_to_list(datas[5])
            melody = eval(datas[3])
            rhy_melody = eval(datas[4])
            rhy_chord = eval(datas[6])
            # 采样展开64旋律序列  
            for n, m in enumerate(melody):
                # 1 表示 4 分音符所以除 0.25转为16分音符
                enhance_melody.extend([m] * int(rhy_melody[n] / 0.25)) 
            # 采样展开16和弦序列
            for n, c in enumerate(chord):
                enhance_chords.extend([c] * rhy_chord[n])

            melody = enhance_melody
            chord = enhance_chords
            keys_list.append(keys2list(key))
            melody_list.extend(melody)
            chord_list.extend(chord)
    return keys_list, melody_list, chord_list

def getDataFromMusicFile(file_path):
    if not os.path.exists(file_path):
        print('[Error] File {} does not exist!'.format(file_path))
        exit(1)
    # Handle labeled data
    np_melody_low = []
    np_chord = []
    np_keys = []

    keys, melody_low, chord = get_data(file_path)
    print(keys.shape, melody_low.shape, chord.shape)
    np_keys.extend(keys)

    for m in melody_low:
        melody_low_ndx = []
        for word in m:
            word = str(word)
            if word not in melody2id:
                print('Error: {}'.format(word))
                exit(0)
            melody_low_ndx.append(melody2id[word])
        np_melody_low.append(melody_low_ndx)

    for c in chord:
        chord_ndx = np.zeros((16, ))
        for n, word in enumerate(c):
            if word not in chord2id:
                print('Error: {}'.format(word))
                exit(0)
            chord_ndx[n] = chord2id[word]
        np_chord.append(chord_ndx)

    start_chord = np.concatenate([[[chord2id['S']]] * len(np_chord)], axis=0)
    start_note = np.concatenate([[[melody2id['S']]] * len(np_melody_low)], axis=0)

    datas = {}
    datas['tone'] = torch.from_numpy(np.array(np_keys))
    datas['melody'] = torch.from_numpy(np.array(np_melody_low)[:,])
    datas['chord_in'] = torch.LongTensor(np.concatenate((start_chord, np_chord), axis=-1))
    datas['note_in'] = torch.LongTensor(np.concatenate((start_note, np_melody_low), axis=-1))
    datas['music_feat'] = 0
    return datas

@torch.no_grad()
def get_res(model, name):
    test_emotion = json.load(open('test_data.json', 'r'))
    datas = getDataFromMusicFile('testdatas/chongerfei_main.txt')
    music_extractor = EmoFeatureExtractor()
    batch_size = datas['note_in'].shape[0]

    seq_notes = []
    seq_chords = []
    pre_outs = None

    for key in test_emotion:
        print(key)
        now_emo = torch.Tensor(test_emotion[key]).float().unsqueeze(0).tile((batch_size, 1, 1))
        now_datas = {
            'tone': datas['tone'].to(device),
            'melody': datas['melody'].to(device),
            'chord_in': datas['chord_in'].to(device),
            'note_in': datas['note_in'].to(device),
            'emotion': now_emo.to(device)
        }
        now_datas['chord_in'][:, 1:] = 0
        now_datas['note_in'][:, 1:] = 0
        
        # inference note
        for i in range(64):
            outs = model(now_datas, pre_outs)
            note_logit = outs['note'].view(batch_size, 65, -1)[:, i, :]
            _, note_ids = torch.topk(note_logit, k=1)
            for n, nid in enumerate(note_ids):
                now_datas['note_in'][n, i + 1] = nid
        # outs = model(now_datas, pre_outs)
        # res
        note_logit = outs['note']
        notes = []
        _, note_ids = torch.topk(note_logit, k=1)
        for nid in note_ids:
            note = id2notes[str(nid.item())]
            if note in ['S', 'E', 'P']:
                note = '0'
            note = eval(note)
            notes.append(note)

        now_notes = []
        for i in range(0, len(notes), 65):
            now_notes.extend(notes[i: i + 64])
        seq_notes.append(now_notes)

        chord_logit = outs['chord']
        chords = []
        _, chord_ids = torch.topk(chord_logit, k=1)

        for cid in chord_ids:
            chord = id2chords[str(cid.item())]
            if chord in ['S', 'E', 'P']:
                chord = '[]'
            chord = eval(chord)
            chords.append(chord)
        
        now_chords = []
        for i in range(0, len(chords), 17):
            now_chords.extend(chords[i: i + 16])
        seq_chords.append(now_chords)

        # get music features
        pre_outs = outs
        pre_outs['music_feat'] = music_extractor(outs, contain_S_E=True).to(device)

    res = {'notes': seq_notes, 'chords': seq_chords}
    saved_path = 'results/{}'.format(name)
    if not os.path.exists(saved_path):
        os.mkdir(saved_path)

    with open(os.path.join(saved_path, '{}.json'.format(name)), 'w') as f:
        f.write(json.dumps(res))

if __name__ == '__main__':
    median = DualMuThera(emo_fusion_type='median').to(device)
    median_ckpt = torch.load('modelzoo/low_median', map_location=device)
    median.load_state_dict(median_ckpt)
    
    # replace = DualMuThera(emo_fusion_type='replace').to(device)
    # replace_ckpt = torch.load('modelzoo/low_replace', map_location=device)
    # replace.load_state_dict(replace_ckpt)

    # concat = DualMuThera(emo_fusion_type='concat').to(device)
    # concat_ckpt = torch.load('modelzoo/low_concat', map_location=device)
    # concat.load_state_dict(concat_ckpt)
    
    get_res(median, 'median_enhance_chongerfei')
    # get_res(concat, 'concat_enhance_chongerfei')
    # get_res(replace, 'replace_enhance_chongerfei')
