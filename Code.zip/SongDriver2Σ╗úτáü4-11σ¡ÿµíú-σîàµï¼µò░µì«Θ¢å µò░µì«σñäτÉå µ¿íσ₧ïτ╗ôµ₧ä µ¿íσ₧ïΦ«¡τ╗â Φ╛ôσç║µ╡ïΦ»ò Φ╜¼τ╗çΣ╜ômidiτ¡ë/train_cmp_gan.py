import json
import torch
import os
import torch.nn as nn
import torch.nn.functional as F
from torchmetrics import Accuracy
from torch.utils.data.dataset import random_split
from config import Config
from tqdm import tqdm
from torch.utils.data import DataLoader
from data.musicDatasetEnhance import AiMusicDataset
from models.gan import GAN


SEED = 3547
torch.manual_seed(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# only use label
NAME = 'TransformerGAN'
LOG_PATH = 'log/{}'.format(NAME)
CKPT_PATH = 'modelzoo/{}'.format(NAME)

if not os.path.exists(LOG_PATH):
    os.mkdir(LOG_PATH)
    
if not os.path.exists(CKPT_PATH):
    os.mkdir(CKPT_PATH)

def pipeline(model, train_loader, eval_loader, test_loader, args, ckpt_pth=None):
    if ckpt_pth:
        ckpt = torch.load(ckpt_pth, map_location=device)
        model.load_state_dict(ckpt)
        print('[Resume] load ckpt {}'.format(ckpt_pth))

    criterion = nn.CrossEntropyLoss(ignore_index=0).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    postfix = {'running_loss': 0.0}

    for epoch in range(args.epoch):
        tqdm_train = tqdm(train_loader, desc='Training (epoch #{})'.format(epoch + 1))
        total_g_loss = 0
        total_d_loss = 0
        g_n = 0
        d_n = 0
        # train generator
        if epoch < 15:
            print('Train Generator')
            # freeze discriminator
            for p in model.discriminator.parameters():
                p.requires_grad = False
            for p in model.generator.parameters():
                p.requires_grad = True
            for batch in tqdm_train:
                # To device
                for key in batch:
                    batch[key] = batch[key].to(device)
                # Load data
                batch_size = batch['melody'].shape[0]
                outputs, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord) = model(batch)
                # generating loss
                g_note_loss = criterion(outputs['note'], batch['note_out'].view(-1))
                g_chord_loss = criterion(outputs['chord'], batch['chord_out'].view(-1))
                g_loss = g_note_loss + g_chord_loss
                
                total_g_loss += g_loss.item()
                g_n += batch_size
                # update generator
                optimizer.zero_grad()
                g_loss.backward()
                optimizer.step()
                postfix['running_loss'] += (g_loss.item() - postfix['running_loss']) / (epoch + 1)
                tqdm_train.set_postfix(postfix)
        # train discriminator
        elif epoch < 30:
            print('Train Discriminator')
            # freeze generator
            for p in model.discriminator.parameters():
                p.requires_grad = True
            for p in model.generator.parameters():
                p.requires_grad = False
            for batch in tqdm_train:
                # To device
                for key in batch:
                    batch[key] = batch[key].to(device)
                # Load data
                batch_size = batch['melody'].shape[0]
                outputs, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord) = model(batch)
                # discriminator loss
                d_chord_loss = -torch.mean(torch.log(d_true_chord) + torch.log(1 - d_fake_chord))
                d_note_loss = -torch.mean(torch.log(d_true_melody) + torch.log(1 - d_fake_melody))
                d_loss = d_chord_loss + d_note_loss
                # Record Loss
                total_d_loss += d_loss.item()
                d_n += batch_size
                # update discriminator
                optimizer.zero_grad()
                d_loss.backward()
                optimizer.step()
                postfix['running_loss'] += (d_loss.item() - postfix['running_loss']) / (epoch + 1)
                tqdm_train.set_postfix(postfix)
        else:
            print('Train Generator and Discriminator')
            for p in model.discriminator.parameters():
                p.requires_grad = True
            for p in model.generator.parameters():
                p.requires_grad = True
            for batch in tqdm_train:
                # To device
                for key in batch:
                    batch[key] = batch[key].to(device)
                # Load data
                batch_size = batch['melody'].shape[0]
                outputs, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord) = model(batch)
                # generating loss
                g_chord_loss = criterion(outputs['chord'], batch['chord_out'].view(-1))
                g_note_loss = criterion(outputs['note'], batch['note_out'].view(-1))
                g_loss = g_note_loss + g_chord_loss
                # discriminator loss
                d_chord_loss = -torch.mean(torch.log(d_true_chord) + torch.log(1 - d_fake_chord))
                d_note_loss = -torch.mean(torch.log(d_true_melody) + torch.log(1 - d_fake_melody))
                d_loss = d_chord_loss + d_note_loss
                # Record Loss
                total_g_loss += g_loss.item()
                total_d_loss += d_loss.item()
                g_n += batch_size
                d_n += batch_size
                # update discriminator
                optimizer.zero_grad()
                d_loss.backward()
                optimizer.step()
                
                postfix['running_loss'] += (d_loss.item() - postfix['running_loss']) / (epoch + 1)
                tqdm_train.set_postfix(postfix)
        # evaluate
        eval_g_loss, eval_d_loss = evaluate(model, eval_loader)
        # test
        chord_acc, note_acc = test(model, test_loader)
        res_json = {
            'epoch': epoch,
            'g_loss': total_g_loss / g_n,
            'd_loss': total_d_loss / d_n,
            'eval_g_loss': eval_g_loss,
            'eval_d_loss': eval_d_loss,
            'test_accuracy_chord': chord_acc.compute().item(),
            'test_accuracy_note': note_acc.compute().item(),
        }

        with open('{}/epochs.json'.format(LOG_PATH), 'a') as f:
            res = json.dumps(res_json)
            f.write(res + '\n')
        # scheduler.step()
        torch.save(model.state_dict(), f'{CKPT_PATH}/{epoch}.ckpt')

@torch.no_grad()
def evaluate(model, loader):
    global device
    model = model.to(device)
    criterion = nn.CrossEntropyLoss(ignore_index=0).to(device)
    # scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer=optimizer, T_max=args.epoch, eta_min=0.0001)
    total_g_loss = 0
    total_d_loss = 0
    n = 0
    for batch in tqdm(loader):
         # To device
        for key in batch:
            batch[key] = batch[key].to(device)
        # Load data
        batch_size = batch['melody'].shape[0]
        outputs, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord) = model(batch)
        # generating loss
        g_chord_loss = criterion(outputs['chord'], batch['chord_out'].view(-1))
        g_note_loss = criterion(outputs['note'], batch['note_out'].view(-1))
        g_loss = g_note_loss + g_chord_loss
        # discriminator loss
        d_chord_loss = -torch.mean(torch.log(d_true_chord) + torch.log(1 - d_fake_chord))
        d_note_loss = -torch.mean(torch.log(d_true_melody) + torch.log(1 - d_fake_melody))
        d_loss = d_chord_loss + d_note_loss
        # Record Loss
        total_g_loss += g_loss.item()
        total_d_loss += d_loss.item()
        n += batch_size
        # record out for T+1
    return total_g_loss / n, total_d_loss / n

@torch.no_grad()
def test(model, loader):
    global device
    chord_acc = Accuracy(task='multiclass', num_classes=17327).to(device)
    note_acc = Accuracy(task='multiclass', num_classes=113).to(device)

    for batch in tqdm(loader):
         # To device
        for key in batch:
            batch[key] = batch[key].to(device)
        # Load data
        batch_size = batch['melody'].shape[0]
        outputs, (d_true_melody, d_true_chord), (d_fake_melody, d_fake_chord) = model(batch)
        # generating loss
        g_chord = outputs['chord']
        g_notes = outputs['note']
        # record out for T+1
        _ = chord_acc(g_chord, batch['chord_out'].view(-1))
        _ = note_acc(g_notes, batch['note_out'].view(-1))

    return chord_acc, note_acc


if __name__ == '__main__':
    args = Config('config_muthera.yaml')
    args.input_start = 'S'
    args.output_start = 'E'
    args.batch_size = 16
    args.epochs = 50
    print(f"batch_size:{args.batch_size}")
    full_dataset = AiMusicDataset('dataset/enhance_labeled.npz', args)
    data_len = len(full_dataset)
    train_set, test_set, eval_set = random_split(full_dataset, [data_len - 2000, 1000, 1000], generator=torch.Generator().manual_seed(SEED))

    train_loader = DataLoader(train_set, args.batch_size, shuffle=True, drop_last=True)
    eval_loader = DataLoader(eval_set, args.batch_size, shuffle=False, drop_last=True)
    test_loader = DataLoader(test_set, args.batch_size, shuffle=False, drop_last=True)
    
    print('Dataloader done.')

    model = GAN().to(device)
    pipeline(model, train_loader, eval_loader, test_loader, args)
